const express = require("express");
const session = require("express-session");
const crypto = require("crypto");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json({ limit: "10kb" }));
app.use(session({
  name: "blackout.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 }
}));

const botToken = process.env.TELEGRAM_BOT_TOKEN;
const botUsername = process.env.TELEGRAM_BOT_USERNAME;

app.get("/config", (_req, res) => res.json({ botUsername: botUsername || null }));

function verifyTelegramAuth(data) {
  if (!botToken || !data || typeof data !== "object") return false;
  const { hash, ...authData } = data;
  if (typeof hash !== "string") return false;
  const authDate = Number(authData.auth_date);
  if (!Number.isFinite(authDate) || Math.abs(Date.now()/1000 - authDate) > 300) return false;

  const checkString = Object.keys(authData).sort()
    .map(key => `${key}=${authData[key]}`).join("\n");
  const secretKey = crypto.createHash("sha256").update(botToken).digest();
  const expected = crypto.createHmac("sha256", secretKey).update(checkString).digest();
  let received;
  try { received = Buffer.from(hash, "hex"); } catch { return false; }
  return received.length === expected.length && crypto.timingSafeEqual(received, expected);
}

app.post("/auth/telegram", (req, res) => {
  if (!verifyTelegramAuth(req.body)) return res.status(401).json({ error: "Подпись Telegram недействительна или данные устарели." });
  const u = req.body;
  req.session.user = {
    id: String(u.id),
    first_name: String(u.first_name || ""),
    last_name: String(u.last_name || ""),
    username: String(u.username || ""),
    photo_url: String(u.photo_url || "")
  };
  res.json({ ok: true, user: req.session.user });
});

app.get("/auth/me", (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: "Не подключён" });
  res.json({ user: req.session.user });
});
app.post("/auth/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

if (!process.env.SESSION_SECRET) {
  console.error("Set SESSION_SECRET in .env before starting.");
  process.exit(1);
}
app.listen(process.env.PORT || 3000, () => console.log("BLACKOUT login server started."));
